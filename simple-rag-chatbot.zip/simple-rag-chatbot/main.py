import os
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss

def load_documents(path="docs"):
    docs = []
    for f in os.listdir(path):
        if f.endswith(".txt"):
            with open(os.path.join(path, f), "r", encoding="utf-8") as file:
                docs.append(file.read())
    return docs

def build_index(docs):
    model = SentenceTransformer("all-MiniLM-L6-v2")
    embeddings = model.encode(docs)
    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(np.array(embeddings))
    return model, index

def retrieve(query, model, index, docs):
    q_emb = model.encode([query])
    _, I = index.search(np.array(q_emb), 1)
    return docs[I[0][0]]

if __name__ == "__main__":
    docs = load_documents()
    model, index = build_index(docs)

    print("Simple RAG Chatbot Ready!")
    while True:
        q = input("You: ")
        if q.lower() in ["exit", "quit"]:
            break
        result = retrieve(q, model, index, docs)
        print("\nAI Retrieved Document:")
        print(result)
        print("----\n")
