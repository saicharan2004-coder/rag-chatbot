# Simple RAG Chatbot

A minimal Retrieval-Augmented Generation (RAG) chatbot using:

- SentenceTransformers for embeddings
- FAISS for vector search
- Python

## Run Locally

```
pip install -r requirements.txt
python main.py
```

Add your text files to the `docs/` folder.
